/* 
 * $Id: $
 */

#ifndef _RSP_H_
#define _RSP_H_

#define RSP_VERSION "1.0"

extern PLUGIN_INFO _pi;

#ifndef TRUE
# define TRUE 1
# define FALSE 0
#endif

#endif /* _RSP_H_ */
