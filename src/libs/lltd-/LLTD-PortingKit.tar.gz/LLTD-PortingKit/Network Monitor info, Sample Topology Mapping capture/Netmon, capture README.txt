
Netmon 3 should be used for Windows Vista.  Download details can be found on http://connect.microsoft.com
A sample packet capture of a topology mapping session (between a Vista mapper and multiple responders) is included as an example of a properly-structured protocol exchange.
