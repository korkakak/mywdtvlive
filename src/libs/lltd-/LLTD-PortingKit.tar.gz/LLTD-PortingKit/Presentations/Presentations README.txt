The implementer is encouraged to view the following content on LLTD and related to device icon creation:
	* "Link Layer Topology Discovery and Enabling Wi-Fi Diagnostics for Network Performance Tuning" : http://www.microsoft.com/whdc/rally/rallylltd.mspx 

	* "How to create Windows Vista� icons?" (see especially the default Vista RTM Network Map icon size, 48x48) : http://www.axialis.com/tutorials/tutorial-iw023.html